from django.apps import AppConfig


class NovoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'novoapp'
